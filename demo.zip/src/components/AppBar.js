import { Component } from "react";



 
export default  class AppBar1 extends Component {


    render () {
 
    return ( 
            <div className="main-dev">
                 <div className="top-area ">
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                    <div className="row">
                        <div className="col-md-3">
                            <div className="brand-logo">
                                <img src="/images/logo.png" alt=""/>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <h3 className="slogan">
                              No Pain No Gain
                            </h3>
                        </div>
                    </div>
                </div>
                <div className="col-md-6">
                  <div className="col-md-3 float-right">
                      <div className="brand-logo-right ">
                          <img src="/images/logo.png" alt=""/>
                      </div>
                  </div>
                </div>
            </div>
        </div>
    </div>
            </div>
       
        );    
};
   
}

