import React, { Component } from "react";
import  "./app.css";
import AppBar1 from "./components/AppBar";


class App extends Component {

    // constructor(){
    //     super();


    // }

    render(){



   return (
      <React.Fragment>
      <AppBar1/>
      <div className="top-area ">
          <div className="container">
              <div className="row">
                  <div className="col-md-6">
                      <div className="row">
                          <div className="col-md-3">
                              <div className="brand-logo">
                                  <img src="/images/logo.png" alt=""/>
                              </div>
                          </div>
                          <div className="col-md-6">
                              <h3 className="slogan">
                                No Pain No Gain
                              </h3>
                          </div>
                      </div>
                  </div>
                  <div className="col-md-6">
                    <div className="col-md-3 float-right">
                        <div className="brand-logo-right ">
                            <img src="/images/logo.png" alt=""/>
                        </div>
                    </div>
                  </div>
              </div>
          </div>
      </div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <div className="container">
      
     
      
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
                
           <div  data-toggle="modal" data-target="#exampleModal">
                <div className="row">
                    <img src="/images/home.png" alt=""/>
                <a className="nav-link" href="#">Home </a>
                </div>  
                </div>  
            </li>
            <li className="nav-item active">
                <div  data-toggle="modal" data-target="#exampleModal">

                <div className="row">
                    <img src="/images/staff.png" alt=""/>
              <a className="nav-link" href="#">Service </a>
                </div>
                </div>
          
            </li>
            <li className="nav-item active">
                <div  data-toggle="modal" data-target="#exampleModal">
                <div className="row">
                    <img src="/images/product.png" alt="" />
              <a className="nav-link" href="#">Products </a>
                </div>
                </div>
                
            </li>

            <li className="nav-item active">
                <div  data-toggle="modal" data-target="#exampleModal">
                <div className="row">
                    <img src="/images/businessman.png" alt="" />
              <a className="nav-link" href="#">About </a>
                </div>
                </div>
            </li>
            
           
           
          </ul>
          
        </div>
    </div>
      </nav>
      </React.Fragment>

   );
    
   };

}
export default  App;